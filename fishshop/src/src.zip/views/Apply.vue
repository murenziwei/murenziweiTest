<template>
  <div>
    <NavModel></NavModel>
  </div>
</template>
<script>
import NavModel from '../components/NavModel.vue'
export default {
  components: {
    NavModel
  }
}
</script>

<style lang="sass" scoped>

</style>
